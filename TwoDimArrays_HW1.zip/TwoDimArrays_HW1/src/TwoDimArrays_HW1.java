/*
	Name: Ryan Wang
	Date: 01/30/18
	Project: TwoDimArrays_HW1
	
	The purpose of this project is to get some practice writing code to do
	basic tasks with two dimensional arrays.  
	
	Please do not alter the main() method or the printArray method.
	
	Please complete the following methods and turn your project in to the google
	classroom when complete.
		sumArray
		sumRow
		sumColumn
		rowIndexWithLargestNumber
		columnIndexWithLargestNumber
		sumAroundLargest

	*****************************************************************************************
	Expected Output - here is what I get when I implement the methods:
	
		***********************************
		numbers1: 
		   3   5   7   9  11  13  15
		   2   4   6   8 -10  12  14
		   1   1   2   3   5   7  12
		
		sumArray: 130
		sumRow 1: 36
		sumColumn 3: 20
		rowIndexWithLargestNumber: 0
		columnIndexWithLargestNumber: 6
		sumAroundLargest: 89
		
		***********************************
		numbers2: 
		   3   5   7   9  11  13  15
		   2   4 120   8  10  12  14
		   1   1   2   3   5   7  12
		
		sumArray: 264
		sumRow 2: 31
		sumColumn 5: 32
		rowIndexWithLargestNumber: 1
		columnIndexWithLargestNumber: 2
		sumAroundLargest: 179
		
		***********************************
		numbers3: 
		 3 5
		 2 9
		 1 1
		
		sumArray: 21
		sumRow 0: 8
		sumColumn 0: 6
		rowIndexWithLargestNumber: 1
		columnIndexWithLargestNumber: 1
		sumAroundLargest: 17
		
		***********************************
		numbers4: 
		 -3 -5
		 -2 -9
		 -1 -6
		
		sumArray: -26
		sumRow 1: -11
		sumColumn 1: -20
		rowIndexWithLargestNumber: 2
		columnIndexWithLargestNumber: 0
		sumAroundLargest: -12
 */
public class TwoDimArrays_HW1
{
	/**
	 * sumArray
	 * 
	 * @param nums - int[][], assumed to be rectangular
	 * @return - the sum of every element in the array
	 */
	public static int sumArray(int[][] nums)
	{
		int sum = 0;
		for (int row = 0; row < nums.length; row++)
		{
			for (int col = 0; col < nums[row].length; col++)
			{
				sum += nums[row][col];
			}
		}
		return sum;
	}
	
	/**
	 * sumRow
	 * 
	 * @param nums - int[][], assumed to be rectangular
	 * @param row - integer row index into nums, assumed to index to a row in the array
	 * @return - the sum of all of the elements in the specified row
	 */
	public static int sumRow(int[][] nums, int row)
	{
		return 0;
	}
	
	/**
	 * sumColumn
	 * 
	 * @param nums - int[][], assumed to be rectangular
	 * @param col - integer column index into nums, assumed to index to a column in the array 
	 * @return - the sum of all the elements in the specified column
	 */
	public static int sumColumn(int[][] nums, int col)
	{
		return 0;
	}
	
	/**
	 * rowIndexWithLargestNumber
	 * 
	 * @param nums - int[][], assumed to be rectangular
	 * @return - the zero index of the row that has the largest number in the 
	 * 				two dimensional array 
	 */
	public static int rowIndexWithLargestNumber(int[][] nums)
	{
		return 0;
	}
	
	/**
	 * columnIndexWithLargestNumber
	 * 
	 * @param nums - int[][], assumed to be rectangular
	 * @return - the zero index of the column that has the largest number in the 
	 * 				two dimensional array 
	 */
	public static int columnIndexWithLargestNumber(int[][] nums)
	{
		return 0;
	}

	/**
	 * sumAroundLargest
	 * 
	 * @param nums - int[][], assumed to be rectangular
	 * @return - Finds the largest number in the array; returns the sum of all of the 
	 * 				numbers in the column that the largest number appears in + the sum
	 * 				of all of the numbers in the row that the largest number appears in.
	 * 
	 *  		 Only count the largest number ONCE in this sum.
	 *  
	 *  Example: If the array looked like this:
	 *  				1  2  3  4  5  6  7  8  
	 * 					9 10 99 12 13 14 15 16
	 * 				   17 18 19 20 21 22 23 24
	 * 
	 * 			 99 is the largest element in the array.  Therefore, row 1 is the row that contains
	 * 				the largest element and column 2 is the column that contains the largest number.
	 * 
	 *   		 The sum we are looking for is the sum of row 1 + the sum of column 2 - but only counting
	 *   			the 99 once.  In other words, the sum we are looking for would be:
	 *   
	 *    				9 + 10 + 99 + 12 + 13 + 14 + 15 + 16 + 3 + 19 == 210
	 *    
	 *  HINT: Use the methods you wrote earlier as utility functions to make this method easy 
	 *  		 to write. 
	 */
	public static int sumAroundLargest(int [][] nums)
	{
		return 0;
	}
	
	/*********************************************
	 * DO NOT ALTER ANY CODE BELOW THIS LINE!!!!!*
	 *********************************************/
	
	public static void main(String[] args) 
	{
		int[][] numbers1 = {
							{ 3, 5, 7, 9,  11, 13, 15 },
							{ 2, 4, 6, 8, -10, 12, 14 }, 
							{ 1, 1, 2, 3,   5,  7, 12 }
						   };

		int[][] numbers2 = {
							{ 3, 5,   7, 9, 11, 13, 15 },
							{ 2, 4, 120, 8, 10, 12, 14 }, 
							{ 1, 1,   2, 3,  5,  7, 12 }
						   };
		
		int[][] numbers3 = {
							{ 3, 5 },
							{ 2, 9 }, 
							{ 1, 1 }
						   };

		int[][] numbers4 = {
							{ -3, -5 },
							{ -2, -9 }, 
							{ -1, -6 }
						   };

		// Test all methods on numbers1
		System.out.println("***********************************");
		System.out.println("numbers1: ");
		printArray(numbers1);
		System.out.println("sumArray: " + sumArray(numbers1));
		System.out.println("sumRow 1: " + sumRow(numbers1, 1));
		System.out.println("sumColumn 3: " + sumColumn(numbers1, 3));
		System.out.println("rowIndexWithLargestNumber: " + rowIndexWithLargestNumber(numbers1));
		System.out.println("columnIndexWithLargestNumber: " + columnIndexWithLargestNumber(numbers1));
		System.out.println("sumAroundLargest: " + sumAroundLargest(numbers1));
		System.out.println();
		
		// Test all methods on numbers2
		System.out.println("***********************************");
		System.out.println("numbers2: ");
		printArray(numbers2);
		System.out.println("sumArray: " + sumArray(numbers2));
		System.out.println("sumRow 2: " + sumRow(numbers2, 2));
		System.out.println("sumColumn 5: " + sumColumn(numbers2, 5));
		System.out.println("rowIndexWithLargestNumber: " + rowIndexWithLargestNumber(numbers2));
		System.out.println("columnIndexWithLargestNumber: " + columnIndexWithLargestNumber(numbers2));
		System.out.println("sumAroundLargest: " + sumAroundLargest(numbers2));
		System.out.println();

		// Test all methods on numbers3
		System.out.println("***********************************");
		System.out.println("numbers3: ");
		printArray(numbers3);
		System.out.println("sumArray: " + sumArray(numbers3));
		System.out.println("sumRow 0: " + sumRow(numbers3, 0));
		System.out.println("sumColumn 0: " + sumColumn(numbers3, 0));
		System.out.println("rowIndexWithLargestNumber: " + rowIndexWithLargestNumber(numbers3));
		System.out.println("columnIndexWithLargestNumber: " + columnIndexWithLargestNumber(numbers3));
		System.out.println("sumAroundLargest: " + sumAroundLargest(numbers3));
		System.out.println();
	
		// Test all methods on numbers4
		System.out.println("***********************************");
		System.out.println("numbers4: ");
		printArray(numbers4);
		System.out.println("sumArray: " + sumArray(numbers4));
		System.out.println("sumRow 1: " + sumRow(numbers4, 1));
		System.out.println("sumColumn 1: " + sumColumn(numbers4, 1));
		System.out.println("rowIndexWithLargestNumber: " + rowIndexWithLargestNumber(numbers4));
		System.out.println("columnIndexWithLargestNumber: " + columnIndexWithLargestNumber(numbers4));
		System.out.println("sumAroundLargest: " + sumAroundLargest(numbers4));
		System.out.println();
	}

	public static void printArray(int[][] grid)
	{
		int maxValue = Integer.MIN_VALUE;
		int minValue = Integer.MAX_VALUE;
		
		for (int row = 0; row < grid.length; row++)
		{
			for (int col = 0; col < grid[row].length; col++)
			{
				maxValue = Math.max(maxValue, grid[row][col]);
				minValue = Math.min(minValue, grid[row][col]);
			}
		}
		
		int digits = Math.max((2 + (int)Math.log10(Math.abs(maxValue)) + ((maxValue < 0 ? 1 : 0))),
							  (2 + (int)Math.log10(Math.abs(minValue)) + ((minValue < 0 ? 1 : 0))));
		
		for (int row = 0; row < grid.length; row++)
		{
			for (int col = 0; col < grid[row].length; col++)
			{
				System.out.print(String.format("%1$" + digits + "s", grid[row][col]));
			}
			System.out.println();
		}
		System.out.println();
	}
	
}
